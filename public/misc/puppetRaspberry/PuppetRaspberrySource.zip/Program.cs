﻿using Microsoft.Extensions.Logging;
using PuppeteerSharp;
using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace PuppetRaspberry {
    class Program {
        static async Task Main(string[] args) {

            string zip = "90210";

            if (args.Length == 1) {
                zip = args[0];
            }


            // setup logger
            var factory = new LoggerFactory();
            factory.AddFile("logme.txt", LogLevel.Error);

            var options = new LaunchOptions() {
                ExecutablePath = @"/usr/bin/chromium-browser",
                Headless = true //,
                //Args = new[] { "--disable-web-security" }
            };

            Stopwatch sw = Stopwatch.StartNew();            
            var browser = await Puppeteer.LaunchAsync(options, factory);
            Console.WriteLine($"Launched Chrome...{sw.ElapsedMilliseconds} ms");

            sw.Restart();
            Console.WriteLine("browser.NewPageAsync()");
            var page = await browser.NewPageAsync();
            Console.WriteLine($"New Page...{sw.ElapsedMilliseconds} ms");

            // get random width
            Random rnd = new Random(Environment.TickCount);
            int width = rnd.Next(600, 1000);
            var viewportOptions = new ViewPortOptions {
                Width = width,
                Height = 0
            };
            //viewportOptions = new ViewPortOptions();

            sw.Restart();
            await page.SetViewportAsync(viewportOptions);
            Console.WriteLine($"SetViewportAsync...{sw.ElapsedMilliseconds} ms");

            string url = "https://stage.xomewidgets.com/widgets/SupplyAndDemandZip?zip={zip}&disableInteractive=true&authorization=5ce31ca28c71a65f8b0c93271a17781eecad4654a5ecb7a7e83cea66";
            url = url.Replace("{zip}", zip);

            sw.Restart();
            await page.GoToAsync(url);
            Console.WriteLine($"Go to URL {url} ... {sw.ElapsedMilliseconds} ms");

            // wait for a selector
            sw.Restart();
            var element = await page.WaitForSelectorAsync(".xw-widget-fully-loaded");
            if (element == null) {
                Console.WriteLine("TakeScreenshot Can't find completion selector");
                throw new Exception("Can't find completion selector");
            }
            Console.WriteLine($"WaitForSelectorAsync... {sw.ElapsedMilliseconds} ms");

            string outputFile = "img.png";
            if (File.Exists(outputFile)) {
                File.Delete(outputFile);
            }

            sw.Restart();
            await page.ScreenshotAsync(outputFile);
            Console.WriteLine($"Took Screenshot...{sw.ElapsedMilliseconds} ms");

            Console.WriteLine("Done");

            page.Dispose();
            browser.Dispose();            
        }
    }
}
