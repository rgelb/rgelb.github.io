﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAutomation {
    class Program {

        static void Main(string[] args) {
            var appArgs = new AppArguments();
            Parser.ParseArgumentsWithUsage(args, appArgs);

            DeleteFile(appArgs.OutputFile);
            BuildSqlFile(appArgs);
        }

        private static void DeleteFile(string file) {
            if (File.Exists(file)) {
                try {
                    File.Delete(file);
                    Console.WriteLine($"Deleted {file}");
                } catch (Exception ex) {
                    Console.WriteLine($"Error deleting file {file}: {ex.Message}");
                }
            }
        }

        private static void BuildSqlFile(AppArguments appArgs) {
            // process data in that order
            var tables = new List<string>();
            var views = new List<string>();
            var functions = new List<string>();
            var storedprocs = new List<string>();
            var data = new List<string>();
            var layouts = new List<string>();
            var scripts = new List<string>();

            // ignore everything that's not Database/DB-TRIO/
            // ignore everything that doesn't end with .sql
            var filePaths = File.ReadAllLines(appArgs.InputFile).ToList()
                .Where(f => f.StartsWith("Database/DB-TRIO/", StringComparison.CurrentCultureIgnoreCase))
                .Where(f => f.EndsWith(".sql", StringComparison.CurrentCultureIgnoreCase));
                

            foreach (var filePath in filePaths) {
                // figure out where the file belongs                                

                // split dir: Database/DB-TRIO/Layouts/All/AutoEmail/
                // 3rd item (index 2) should tell us what it is.
                string[] dirs = filePath.Split("/".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

                string type = dirs[2];
                string fullPath = Path.GetFullPath(Path.Combine(appArgs.BasePath, filePath));

                switch (type.ToLower()) {
                    case "tables":
                        tables.Add(fullPath);
                        break;
                    case "views":
                        views.Add(fullPath);
                        break;
                    case "functions":
                        functions.Add(fullPath);
                        break;
                    case "storedprocs":
                        storedprocs.Add(fullPath);
                        break;
                    case "data":
                        data.Add(fullPath);
                        break;
                    case "layouts":
                        layouts.Add(fullPath);
                        break;
                    case "scripts":
                        scripts.Add(fullPath);
                        break;
                    default:
                        Console.WriteLine($"What is this: {type}");
                        break;
                }
            }

            // build all files

            var allFiles = tables.Concat(views).Concat(functions)
                            .Concat(storedprocs).Concat(data)
                            .Concat(layouts).Concat(scripts).ToList();

            foreach (var item in allFiles) {
                WriteFileTo(item, appArgs.OutputFile);
            }

            Console.WriteLine($"Built {appArgs.OutputFile} with {allFiles.Count} files");
        }

        private static void WriteFileTo(string file, string outputFile) {
            // get content
            string content = File.ReadAllText(file);

            // add separator
            content += Environment.NewLine + $"PRINT '{file}'" + Environment.NewLine;
            content += Environment.NewLine + "GO" + Environment.NewLine;

            File.AppendAllText(outputFile, content);
        }
    }

    [CommandLineArguments(CaseSensitive = false)]
    public class AppArguments {
        [Argument(ArgumentType.Required, HelpText = "Input File", LongName = "InputFile", ShortName = "i")]
        public string InputFile;

        [Argument(ArgumentType.Required, HelpText = "Output File", LongName = "OutputFile", ShortName = "o")]
        public string OutputFile;

        [Argument(ArgumentType.AtMostOnce, HelpText = "Base Path", DefaultValue = @"C:\Projects\net2", LongName = "BasePath", ShortName = "b")]
        public string BasePath;
    }
}
